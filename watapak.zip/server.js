const express = require('express');
const axios = require('axios');
const path = require('path');
const bodyParser = require('body-parser');
const { Telegraf } = require('telegraf');

const app = express();
const PORT = process.env.PORT || 3000;

const TELEGRAM_BOT_TOKEN = '7240533750:AAEEV3EXxLtsGX-A2T0-0JEyxptAa-O66fo';
const bot = new Telegraf(TELEGRAM_BOT_TOKEN);

bot.command('start', (ctx) => {
    console.log('Received /start command');
    const chatId = ctx.chat.id;
    const username = ctx.message.from.username;
    ctx.reply(`Chat ID grup ini adalah: ${chatId}`);
    console.log(`Chat ID: ${chatId}`);
});

bot.launch();


let users = [
    { id: 1, username: 'admin', password: 'admin', role: 'admin', telegramChatId: -4197535723 },
    { id: 2, username: 'user', password: 'user', role: 'user', telegramChatId: null },
    { id: 3, username: 'admin1', password: 'admin1', role: 'admin', telegramChatId: null },
    { id: 4, username: 'cerita77', password: 'cerita77', role: 'admin', telegramChatId: null }
];

let urls = [
    { url: 'https://cerita77server.xyz', description: 'Utama Domain CR77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 1 },
    { url: 'https://top77sushigaming.click', description: 'Cano TG77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 1 },
    { url: 'https://www.win77gamingresmi.cfd', description: 'Utama Domain WG77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 2 },
    { url: 'https://cerita77alt.store', description: 'Alt Domain CR77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 2 },
    { url: 'https://topgaming77official.click', description: 'Alt Domain TG77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 3 },
    { url: 'https://wingaming77link.cfd', description: 'Alt Domain WG77', status: 'Checking', lastChecked: 'Never', notified: false, userId: 3 },
];

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
        res.json({ success: true, user });
    } else {
        res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
});

app.get('/api/urls', (req, res) => {
    const userId = parseInt(req.query.userId);
    res.json(urls.filter(url => url.userId === userId));
});

app.post('/api/urls', (req, res) => {
    const newUrl = req.body;
    newUrl.status = 'Checking';
    newUrl.lastChecked = 'Never';
    newUrl.notified = false;
    urls.push(newUrl);
    checkUrl(newUrl);
    res.json(urls.filter(url => url.userId === newUrl.userId));
});

app.delete('/api/urls/:index', (req, res) => {
    const index = req.params.index;
    const userId = req.query.userId;
    urls = urls.filter((url, i) => i !== parseInt(index) || url.userId !== parseInt(userId));
    res.json(urls.filter(url => url.userId === parseInt(userId)));
});

app.put('/api/users/chatId', (req, res) => {
    const { username, telegramChatId } = req.body;
    const user = users.find(u => u.username === username);
    if (user) {
        user.telegramChatId = telegramChatId;
        res.json({ success: true, message: 'Telegram Chat ID updated successfully' });
    } else {
        res.status(404).json({ success: false, message: 'User not found' });
    }
});

app.get('/api/users', (req, res) => {
    res.json(users);
});

app.delete('/api/users/:id', (req, res) => {
    const id = parseInt(req.params.id);
    users = users.filter(user => user.id !== id);
    res.json({ success: true });
});

app.get('/api/getUserRole', (req, res) => {
    res.json({ role: 'admin' });
});

app.put('/api/users/:id/password', (req, res) => {
    const id = parseInt(req.params.id);
    const { newPassword } = req.body;
    const user = users.find(u => u.id === id);
    if (user) {
        user.password = newPassword;
        res.json({ success: true, message: 'Password updated successfully' });
    } else {
        res.status(404).json({ success: false, message: 'User not found' });
    }
});

async function sendTelegramMessage(chatId, message) {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    try {
        await axios.post(url, {
            chat_id: chatId,
            text: message,
            parse_mode: 'Markdown'
        });
    } catch (error) {
        console.error('Error sending message to Telegram:', error);
    }
}

async function checkDomain(domain) {
    try {
        const response = await axios.get(`https://${domain}`, { maxRedirects: 0 });
        const ip = response.request.socket.remoteAddress;
        return { domain, ip, status: ip === '36.86.63.185' ? 'blocked' : 'allowed' };
    } catch (error) {
        return { domain, status: 'blocked' };
    }
}

async function checkUrl(url) {
    if (url.status === 'Blocked') {
        return;
    }

    try {
        const response = await axios.get(url.url, { maxRedirects: 0 });
        const ip = response.request.socket.remoteAddress;

        console.log(`Checking URL: ${url.url}, IP: ${ip}`);

        if (ip === '36.86.63.185') {
            url.status = 'Blocked';
            if (!url.notified) {
                const user = users.find(u => u.id === url.userId);
                if (user && user.telegramChatId) {
                    sendTelegramMessage(user.telegramChatId, `🚫 URL terblokir: ${url.url}\nDescription: ${url.description}`);
                }
                url.notified = true;
            }
        } else {
            url.status = 'Safe';
            url.notified = false;
        }
    } catch (error) {
        if (error.response && error.response.status === 301) {
            url.status = 'Redirected (301)';
            if (!url.notified) {
                const user = users.find(u => u.id === url.userId);
                if (user && user.telegramChatId) {
                    sendTelegramMessage(user.telegramChatId, `🔄 URL mengarah ke redirect 301: ${url.url}\nRedirect to: ${error.response.headers.location}\nDescription: ${url.description}`);
                }
                url.notified = true;
            }
        } else {
            console.error(`Error checking URL: ${url.url}`, error);
            url.status = 'Blocked';
            if (!url.notified) {
                const user = users.find(u => u.id === url.userId);
                if (user && user.telegramChatId) {
                    sendTelegramMessage(user.telegramChatId, `🚫 URL terblokir karena tidak dapat dijangkau: ${url.url}\nDescription: ${url.description}`);
                }
                url.notified = true;
            }
        }
    }
    url.lastChecked = new Date().toLocaleString();
    console.log(`URL checked: ${url.url}, Status: ${url.status}, Last Checked: ${url.lastChecked}`);
}

async function checkUrls() {
    for (const url of urls) {
        await checkUrl(url);
    }
}

setInterval(checkUrls, 120000);

bot.command('start', (ctx) => {
    const chatId = ctx.chat.id;
    const username = ctx.message.from.username;
    ctx.reply(`Chat ID grup ini adalah: ${chatId}`);
});

bot.launch();

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    checkUrls();
});